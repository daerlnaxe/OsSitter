# Installation
> Work in progress

> :information_source: It's just a little help if you are lost.

## Linux
- (optionnal) Install git
```
dnf install git
```
- Clone the repository
```
git clone https://github.com/daerlnaxe/OsSitter
```
- ~~Creating a service account for OsSitter.~~
Use the LinuxInstaller.sh