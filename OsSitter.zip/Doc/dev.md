
# Todo
- Add new features like
    - [ ] uptime
    - [x] free mem
    - [ ] inodes
    - [ ] Signal when new config.json file consumed
    - [ ] free space
    - [ ] Custom command
    - [ ] Securities
- [x] Move mails part
- [ ] Check installer to verify if Ressources folder is correctly moved during installation.
- [ ] improving mail features
	- [ ]  Timestamp
- [ ] See possibilities to send cli message to all users connected on linux.
- [ ] I still standing, yeah, yeah, yeah (daily mail)

<br>


# Changelog
## Alpha 5.60
2025/11/02
- Introducing horodating for the log filename

## Alpha 5.1
06/2024
- New feature: "functions"
    - First, memory test with alerting
- BugFix:
	- Hot config loading
 - Improving:
 	- Split for mails part. 

## Alpha 4.1
07/01/2024
- Installer.sh for Linux installation as a service
- Corrections: 
	- Some visual bugs.
- Visual:
	- Show program version
	- Show language version
- Rebuild a json config file at starting, if missing.
- DxHelios: 
    - warning message

## Alpha 4.0
06/01/2024
- Moved all language part to a file
- A new module to write text and format it
- Rewriting everything to make it clean

<br>

# Sums
```

```
